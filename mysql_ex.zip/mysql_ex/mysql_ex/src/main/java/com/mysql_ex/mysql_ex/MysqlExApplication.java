package com.mysql_ex.mysql_ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MysqlExApplication {

	public static void main(String[] args) {
		SpringApplication.run(MysqlExApplication.class, args);
	}
}
